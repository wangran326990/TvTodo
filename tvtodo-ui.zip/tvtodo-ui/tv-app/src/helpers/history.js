/**
 * Created by wr on 24/03/18.
 */
import {createBrowserHistory} from "history";

export const history = createBrowserHistory();