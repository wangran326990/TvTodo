/**
 * Created by wr on 30/03/18.
 */
export * from'./subscribedbody.component';
export * from './searchbody.component';