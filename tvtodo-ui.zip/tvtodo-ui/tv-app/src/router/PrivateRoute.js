/**
 * Created by wr on 27/03/18.
 */
import React from 'react';
import { Route, Redirect } from 'react-router-dom';


/*
 localStorage.getItem('user')
 ? <Component {...props} />
 : <Redirect to={{ pathname: '/login', state: { from: props.location } }>
 */
export const PrivateRoute = ({ component: Component,homepageBody:HomepageBody, ...rest }) => {
    //console.log(HomepageBody);
    if(HomepageBody) {
        return (
            <Route {...rest} render={props => (
                localStorage.getItem('user')? <Component homepageBody={<HomepageBody />}  {...props } />
                    : <Redirect to={{ pathname: '/login', state: { from: props.location } }} />

            )}/>)
    }else{
        return (
            <Route {...rest} render={props => (
                localStorage.getItem('user')? <Component {...props } />
                    : <Redirect to={{ pathname: '/login', state: { from: props.location } }} />

            )}/>)
    }
};