/**
 * Created by wr on 27/03/18.
 */
import React from 'react';
import{Route, Router} from 'react-router-dom';
import {history} from '../helpers';
import {PrivateRoute,LoginRoute} from'../router';
import {HomePage} from '../pages/home-page';
import {RegisterPage} from '../pages/register-page';
import {LoginPage} from '../pages/login-page';
import {SearchBody, SubScribedBody} from '../pages/components';

export class App extends React.Component {
    render(){
      return (  <Router history={history}>
                    <div>

                        <LoginRoute path="/login" component={LoginPage} />
                        <Route path="/register" component={RegisterPage} />
                        <PrivateRoute exact path='/' component={HomePage} homepageBody={SearchBody} />
                        <PrivateRoute exact path='/subscriptions' component={HomePage} homepageBody={SubScribedBody} />

                    </div>
                </Router>)
    }
}
