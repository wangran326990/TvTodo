/**
 * Created by wr on 19/03/18.
 */
export const  alertConstants ={
    SUCCESS: 'ALERT_SUCCESS',
    ERROR: 'ALERT_ERROR',
    CLEAR: 'ALERT_CLEAR'
}