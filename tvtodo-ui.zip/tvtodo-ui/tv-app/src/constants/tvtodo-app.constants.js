/**
 * Created by wr on 24/03/18.
 */
export const user_api={
        USER_LOGIN_REQUEST_URL:"http://localhost:8888/tvtodo/login",
        GET_USER_BY_ID_URL:"",
        USER_LOGOUT_REQUEST_URL:"",
        USER_UPDATE_REQUEST_URL:"",
        USER_REGISTER_REQUEST_URL:"http://localhost:8888/tvtodo/add"
};

export const country_api ={
        COUNTRY_NAME_AND_COUNTRYCODE_URL:"http://country.io/names.json"
};