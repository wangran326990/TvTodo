/**
 * Created by wr on 25/03/18.
 */
import {userConstants} from '../constants';

export function users(state = {}, action) {
    switch (action.type) {

        default:
            return state
    }
}